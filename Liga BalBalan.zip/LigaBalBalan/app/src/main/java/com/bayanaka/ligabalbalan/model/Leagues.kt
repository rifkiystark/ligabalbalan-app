package com.bayanaka.ligabalbalan.model

data class Leagues(val id: String, val imagesSrc : Int, val leagueName : String, val description : String)